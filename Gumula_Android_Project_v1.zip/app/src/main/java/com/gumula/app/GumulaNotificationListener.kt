package com.gumula.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class GumulaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // v1 scaffold: notifications are received here.
        // Production version should persist only the minimum necessary
        // metadata/content locally, encrypt storage, and purge entries older than 1 month.
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
}
