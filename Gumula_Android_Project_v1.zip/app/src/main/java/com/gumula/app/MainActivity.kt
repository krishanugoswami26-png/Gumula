package com.gumula.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip

data class GumulaApp(val name: String, val emoji: String)

@OptIn(ExperimentalFoundationApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GumulaAppUi() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GumulaAppUi() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("home") }
    var dark by remember { mutableStateOf(false) }
    var apps by remember {
        mutableStateOf(listOf(
            GumulaApp("WhatsApp","💬"), GumulaApp("Instagram","📷"),
            GumulaApp("Facebook","ⓕ"), GumulaApp("Messenger","💭"),
            GumulaApp("Telegram","✈️"), GumulaApp("Snapchat","👻"),
            GumulaApp("Messages","✉️"), GumulaApp("Other","➕")
        ))
    }
    var dragFrom by remember { mutableStateOf<Int?>(null) }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().pointerInput(page) {
                    detectHorizontalDragGestures { _, amount ->
                        if (amount < -35) page = "settings"
                        if (amount > 35) page = "notifications"
                    }
                }
            ) {
                Text(
                    "Gumula 🧩",
                    Modifier.fillMaxWidth().padding(top=22.dp, start=20.dp, end=20.dp),
                    fontSize=28.sp, fontWeight=FontWeight.Bold
                )
                Text(
                    when(page) {
                        "settings" -> "Settings"
                        "notifications" -> "Notifications"
                        else -> "Your apps"
                    },
                    Modifier.padding(horizontal=20.dp, vertical=6.dp),
                    color=MaterialTheme.colorScheme.onSurfaceVariant
                )

                when(page) {
                    "settings" -> SettingsPage(dark, { dark = it }, context) { page = "home" }
                    "notifications" -> NotificationsPage { page = "home" }
                    else -> {
                        Text("Swipe left for settings • Swipe right for notifications",
                            Modifier.padding(horizontal=20.dp, vertical=8.dp), fontSize=12.sp)
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.fillMaxSize().padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            itemsIndexed(apps, key = { _, a -> a.name }) { index, app ->
                                AppTile(
                                    app = app,
                                    dragging = dragFrom == index,
                                    onLongPress = { dragFrom = index },
                                    onDrop = {
                                        val from = dragFrom
                                        if (from != null && from != index) {
                                            val copy = apps.toMutableList()
                                            val item = copy.removeAt(from)
                                            copy.add(index, item)
                                            apps = copy
                                        }
                                        dragFrom = null
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppTile(app: GumulaApp, dragging: Boolean, onLongPress: () -> Unit, onDrop: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(100.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (dragging) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { onLongPress() },
                    onHorizontalDrag = { _, _ -> },
                    onDragEnd = { onDrop() },
                    onDragCancel = { onDrop() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(app.emoji, fontSize=30.sp)
            Text(app.name, fontSize=11.sp)
        }
    }
}

@Composable
fun SettingsPage(dark: Boolean, setDark: (Boolean)->Unit, context: android.content.Context, back: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Button(onClick=back) { Text("← Home") }
        Spacer(Modifier.height(12.dp))
        SettingRow("🔀 Rearrange Apps", "Drag apps on Home to change their order")
        SettingRow("🔮 Future", "GPT-powered updates without sending private notification content")
        Row(Modifier.fillMaxWidth().padding(vertical=14.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("🎨 Theme", fontWeight=FontWeight.SemiBold)
                Text(if (dark) "Dark" else "Light", fontSize=12.sp)
            }
            Switch(checked=dark, onCheckedChange=setDark)
        }
        SettingRow("🔔 Notification Sound", "8+ sounds • per-app or all apps")
        SettingRow("🗑️ Retention", "Automatically remove notification history after 1 month")
        SettingRow("💾 Storage", "Target limit: 500 MB")
        SettingRow("🔒 Privacy", "Data stays on-device by default")
        Button(
            onClick = { context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) },
            modifier=Modifier.fillMaxWidth().padding(top=8.dp)
        ) { Text("Enable Notification Access") }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical=10.dp)) {
        Text(title, fontWeight=FontWeight.SemiBold)
        Text(subtitle, fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NotificationsPage(back: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Button(onClick=back) { Text("← Home") }
        Spacer(Modifier.height(16.dp))
        Text("Notifications", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Chronological notification history will appear here once Notification Access is enabled.")
        Spacer(Modifier.height(18.dp))
        Text("Retention: 1 month • Local storage • 500 MB target", fontSize=12.sp)
    }
}
