# Gumula 🧩 — Android v1 scaffold

Gumula is a privacy-focused notification/app hub.

Included in this starter project:
- Gumula branding
- Old-iPhone-inspired rounded app tiles
- Home grid
- Swipe left: Settings
- Swipe right: Notifications
- Drag/reorder app tiles
- Light/dark theme
- Notification Listener service scaffold
- Notification access button
- 1-month retention and 500 MB storage requirements documented in UI

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on an Android phone.

## Important
Android does not provide a universal API to read private message databases of other apps.
Gumula therefore uses NotificationListenerService and must obtain the user's explicit Notification Access permission.

The "Future" GPT feature is intentionally a privacy boundary in this scaffold. A production implementation should send no notification/message content to an external AI service unless the user explicitly opts in.

This is a starter project, not a finished production APK. Persistence, true cross-app icon/package discovery, encrypted notification database, 1-month purge job, 500 MB quota enforcement, notification sounds, and robust drag-and-drop persistence should be completed before release.
